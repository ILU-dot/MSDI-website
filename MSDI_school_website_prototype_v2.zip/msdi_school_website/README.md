# MSDI School Website Prototype

School: Madarasatul Saqafatul Dinil Islam (MSDI)
Location: Bauchi, Nigeria
Levels: Primary 1–5 and JSS1–SS3
Motto shown: Knowledge Is Light (from the supplied logo)
Palette: blue, magenta and orange (from the supplied logo)

The supplied school logo is included as-is at `assets/msdi-logo.jpg`; the design has been adjusted so the emblem and ribbon are not circularly cropped.

## Preview locally
1. Extract the ZIP file.
2. Keep `index.html` and the `assets` folder together.
3. Open `index.html` in a browser. No build tools or installation are required.

## Important limitations
This is a static, front-end prototype. It does not publish itself online, store submissions, authenticate users, or connect to a school database. The results form displays only fictional sample data when the ID `MSDI-DEMO-001` is entered. Never enter real student information into this demo.

## Suggested free publishing path
- Create or use an authorised school Google account.
- For a simple public website, reproduce the content in Google Sites at https://sites.google.com/ and publish to a free Google Sites address.
- If you want to host this exact HTML prototype, use a static hosting service with a free tier (for example, GitHub Pages). Upload `index.html` and the `assets` folder together. This requires a GitHub account and basic repository setup.
- Obtain the director's approval for all copy, photographs, phone numbers, admission details, policies and publication.

## Recommended production results portal architecture
Do not put student results in public HTML, public spreadsheets, JavaScript files, or a publicly shared document.

Recommended design:
1. Front end: MSDI website with a results sign-in page.
2. Authentication: individual parent/student accounts, or another school-approved verified login method. Avoid student name or class as the only secret.
3. Backend: server-side API checks the signed-in user's permissions for the requested student and academic term on every request.
4. Database: private records with role-based access for authorised staff; encrypt data in transit and at rest where supported.
5. Workflow: teacher submits scores -> Exams Officer checks subject entries and calculations -> authorised management approves -> portal releases approved reports.
6. Audit trail: record score changes, approvals and report access; restrict staff permissions to the minimum necessary.
7. Recovery and protection: backups, secure account recovery, rate limiting, logging, and a documented process for correcting errors.
8. Privacy: publish a clear privacy notice, collect only necessary information, set retention rules, and obtain management approval before using children's data online.
9. Testing: use fictional records first; test access denial, incorrect IDs, role boundaries, grade calculations, report generation and mobile display.
10. Launch: pilot with a small authorised group, fix issues, then open to parents and students.

A static website or Google Sites alone cannot provide the complete secure results portal. Treat that as a separate phase that needs a backend/database service and careful testing.

## Before publication checklist
- [ ] School management approves the website content.
- [ ] Confirm official name, motto, school address, phone and email.
- [ ] Confirm classes (Primary 1–5 and JSS1–SS3).
- [ ] Add only approved school photos; get appropriate consent.
- [ ] Verify all navigation and contact links.
- [ ] Remove any placeholder content that has not been confirmed.
- [ ] Keep real student scores and personal information out of the demo.

## How to edit after publishing
- Keep the website files in an account owned by the school or an authorised school representative.
- On GitHub Pages, edit `index.html` in the repository and replace files in `assets` when needed; the public site updates after the changes are committed.
- For a no-code editor, recreate the pages in Google Sites while signed into the school's own Google account. Google Sites does not directly edit this HTML ZIP.
- Do not share account passwords. Add trusted staff as collaborators with the minimum permissions they need.
